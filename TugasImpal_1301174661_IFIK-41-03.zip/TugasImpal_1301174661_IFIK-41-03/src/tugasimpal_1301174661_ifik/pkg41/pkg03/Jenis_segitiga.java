package tugasimpal_1301174661_ifik.pkg41.pkg03;

/**
 *
 * @author Kamila Hanum
 */
import java.util.Scanner ;
public class Jenis_segitiga {
public static void main (String [] args) {
  Scanner nilai= new Scanner (System.in);
  int sisi1, sisi2 ,sisi3 ;
  
System.out.print ("Input panjang sisi ke-1 = ");
sisi1 = nilai.nextInt ();
System.out.print ("Input panjang sisi ke-2 = ");
sisi2 = nilai.nextInt ();
System.out.print ("Input panjang sisi ke-3 = ");
sisi3 = nilai.nextInt ();


if ((sisi1 == 0) || (sisi2 == 0) || (sisi3 == 0)) {
 System.out.println("Bukan Segitiga");
} else {
if ((sisi1 == sisi2) && (sisi3 == sisi1))
 System.out.println("Segitiga Sama Sisi");
else
if ((sisi1 == sisi2) || (sisi1 == sisi3) || (sisi2 == sisi3))
 System.out.println("Segitiga Sama Kaki");
else
 System.out.println("Segitiga Sembarang");
 }
    }
} 